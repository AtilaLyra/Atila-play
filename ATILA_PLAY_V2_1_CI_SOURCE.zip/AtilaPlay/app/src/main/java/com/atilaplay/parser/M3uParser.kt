package com.atilaplay.parser

data class ParsedM3uItem(val name: String, val logoUrl: String?, val groupTitle: String?, val tvgId: String?, val streamUrl: String)

class M3uParser {
    fun parse(content: String): List<ParsedM3uItem> {
        val out = mutableListOf<ParsedM3uItem>()
        var meta: String? = null
        for (raw in content.lineSequence()) {
            val line = raw.trim()
            when {
                line.startsWith("#EXTINF", true) -> meta = line
                line.isNotEmpty() && !line.startsWith("#") && meta != null -> {
                    out += ParsedM3uItem(
                        name = meta!!.substringAfterLast(',', "Sem título").trim(),
                        logoUrl = attr(meta!!, "tvg-logo"),
                        groupTitle = attr(meta!!, "group-title"),
                        tvgId = attr(meta!!, "tvg-id"),
                        streamUrl = line
                    )
                    meta = null
                }
            }
        }
        return out
    }
    private fun attr(line: String, key: String): String? = Regex("$key\\s*=\\s*[\\\"']([^\\\"']*)[\\\"']", RegexOption.IGNORE_CASE).find(line)?.groupValues?.get(1)
}
