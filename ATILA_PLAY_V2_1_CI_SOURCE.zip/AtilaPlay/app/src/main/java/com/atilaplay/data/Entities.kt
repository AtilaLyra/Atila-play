package com.atilaplay.data

import androidx.room.*

@Entity(tableName = "sources")
data class SourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val playlistUrl: String,
    val username: String? = null,
    val password: String? = null,
    val enabled: Boolean = true,
    val lastSyncAt: Long? = null
)

@Entity(tableName = "media", indices = [Index("sourceId"), Index("title"), Index("groupTitle")])
data class MediaEntity(
    @PrimaryKey val id: String,
    val sourceId: Long,
    val title: String,
    val type: String,
    val groupTitle: String? = null,
    val logoUrl: String? = null,
    val streamUrl: String,
    val adult: Boolean = false,
    val seriesId: String? = null,
    val season: Int? = null,
    val episode: Int? = null
)

@Entity(tableName = "favorites", primaryKeys = ["profileId", "mediaId"])
data class FavoriteEntity(val profileId: String, val mediaId: String)

@Entity(tableName = "history", primaryKeys = ["profileId", "mediaId"])
data class HistoryEntity(
    val profileId: String, val mediaId: String,
    val positionMs: Long = 0, val durationMs: Long = 0,
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "epg", indices = [Index("channelId"), Index("start")])
data class EpgEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val channelId: String, val start: Long, val end: Long,
    val title: String, val description: String? = null
)
