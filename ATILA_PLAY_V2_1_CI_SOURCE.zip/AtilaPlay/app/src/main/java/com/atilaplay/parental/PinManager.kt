package com.atilaplay.parental

import android.content.Context
import java.security.MessageDigest

class PinManager(context: Context) {
    private val prefs = context.getSharedPreferences("parental", Context.MODE_PRIVATE)
    private fun hash(pin: String): String = MessageDigest.getInstance("SHA-256").digest(pin.toByteArray()).joinToString("") { "%02x".format(it) }
    init { if (!prefs.contains("pin")) prefs.edit().putString("pin", hash("0000")).apply() }
    fun verify(pin: String): Boolean = prefs.getString("pin", "") == hash(pin)
    fun setPin(pin: String) { require(pin.length == 4 && pin.all(Char::isDigit)); prefs.edit().putString("pin", hash(pin)).apply() }
}
