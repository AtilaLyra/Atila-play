package com.atilaplay

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); setContent { AtilaPlayApp() } }
}

@Composable fun AtilaPlayApp() {
    var logged by remember { mutableStateOf(false) }
    MaterialTheme(colorScheme = darkColorScheme()) { if (logged) HomeScreen() else LoginScreen { logged = true } }
}

@Composable fun LoginScreen(onLogin: () -> Unit) {
    var url by remember { mutableStateOf("http://") }; var user by remember { mutableStateOf("") }; var pass by remember { mutableStateOf("") }
    Box(Modifier.fillMaxSize().background(Color(0xFF08090C)), Alignment.Center) {
        Column(Modifier.widthIn(max = 560.dp).padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("ATILA PLAY", fontSize = 40.sp, fontWeight = FontWeight.Bold); Text("Cliente de mídia para Android e TV")
            Spacer(Modifier.height(24.dp)); OutlinedTextField(url, { url = it }, label = { Text("Servidor / URL") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp)); OutlinedTextField(user, { user = it }, label = { Text("Usuário") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp)); OutlinedTextField(pass, { pass = it }, label = { Text("Senha") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(18.dp)); Button(onClick = onLogin, modifier = Modifier.fillMaxWidth().height(52.dp)) { Text("ENTRAR") }
        }
    }
}

@Composable fun HomeScreen() {
    val sections = listOf("🔥 ANIMES EM ALTA", "▶ CONTINUAR ASSISTINDO", "📡 CANAIS", "🎬 FILMES", "📺 SÉRIES")
    Column(Modifier.fillMaxSize().background(Color(0xFF08090C)).padding(28.dp)) {
        Text("ATILA PLAY", fontSize = 30.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp))
        Text("Início   Canais   Filmes   Séries   Animes   Minha Lista   Buscar   ⚙", color = Color.LightGray)
        Spacer(Modifier.height(20.dp))
        sections.forEach { title ->
            Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold); Spacer(Modifier.height(8.dp))
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items((1..6).toList()) { i ->
                    Card(Modifier.width(160.dp).height(220.dp)) { Box(Modifier.fillMaxSize(), Alignment.Center) { Text("$title\nItem $i", modifier = Modifier.padding(10.dp)) } }
                }
            }; Spacer(Modifier.height(18.dp))
        }
    }
}
