package com.atilaplay.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao interface SourceDao {
    @Query("SELECT * FROM sources ORDER BY name") fun observeAll(): Flow<List<SourceEntity>>
    @Query("SELECT * FROM sources WHERE enabled = 1") suspend fun getEnabled(): List<SourceEntity>
    @Insert suspend fun insert(source: SourceEntity): Long
    @Update suspend fun update(source: SourceEntity)
    @Delete suspend fun delete(source: SourceEntity)
    @Query("UPDATE sources SET lastSyncAt = :time WHERE id = :id") suspend fun markSynced(id: Long, time: Long)
}

@Dao interface MediaDao {
    @Query("SELECT * FROM media WHERE type = :type ORDER BY title") fun observeByType(type: String): Flow<List<MediaEntity>>
    @Query("SELECT * FROM media WHERE title LIKE '%' || :query || '%' ORDER BY title LIMIT 100") suspend fun search(query: String): List<MediaEntity>
    @Query("SELECT * FROM media WHERE adult = 0 ORDER BY title LIMIT 100") suspend fun getNonAdult(): List<MediaEntity>
    @Query("SELECT * FROM media WHERE type = :type AND adult = 0 ORDER BY title LIMIT 100") suspend fun getType(type: String): List<MediaEntity>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun upsertAll(items: List<MediaEntity>)
    @Query("DELETE FROM media WHERE sourceId = :sourceId AND id NOT IN (:ids)") suspend fun deleteMissing(sourceId: Long, ids: List<String>)
    @Query("DELETE FROM media WHERE sourceId = :sourceId") suspend fun deleteAll(sourceId: Long)
}

@Dao interface FavoriteDao {
    @Query("SELECT mediaId FROM favorites WHERE profileId = :profileId") fun observeIds(profileId: String): Flow<List<String>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun add(item: FavoriteEntity)
    @Query("DELETE FROM favorites WHERE profileId = :profileId AND mediaId = :mediaId") suspend fun remove(profileId: String, mediaId: String)
}

@Dao interface HistoryDao {
    @Query("SELECT * FROM history WHERE profileId = :profileId ORDER BY updatedAt DESC LIMIT 50") fun observe(profileId: String): Flow<List<HistoryEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun save(item: HistoryEntity)
    @Query("SELECT * FROM history WHERE profileId = :profileId AND mediaId = :mediaId LIMIT 1") suspend fun find(profileId: String, mediaId: String): HistoryEntity?
}

@Dao interface EpgDao {
    @Query("SELECT * FROM epg WHERE channelId = :channelId AND end >= :now ORDER BY start") fun observe(channelId: String, now: Long): Flow<List<EpgEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insertAll(items: List<EpgEntity>)
    @Query("DELETE FROM epg WHERE end < :now") suspend fun deleteExpired(now: Long)
}
