package com.atilaplay.player

import android.content.Context
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer

class PlayerManager(context: Context) {
    val player: ExoPlayer = ExoPlayer.Builder(context).build()
    fun play(url: String) { player.setMediaItem(MediaItem.fromUri(url)); player.prepare(); player.play() }
    fun release() = player.release()
}
