package com.atilaplay.sync

import com.atilaplay.data.*
import com.atilaplay.parser.M3uParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest

class SourceSynchronizer(private val db: AppDatabase) {
    private val parser = M3uParser()

    suspend fun synchronize(source: SourceEntity): Result<Int> = withContext(Dispatchers.IO) {
        runCatching {
            val content = download(source.playlistUrl)
            val parsed = parser.parse(content)
            val items = parsed.map { item ->
                MediaEntity(
                    id = stableId(source.id, item.tvgId ?: item.name, item.streamUrl),
                    sourceId = source.id,
                    title = item.name,
                    type = classify(item.groupTitle, item.name),
                    groupTitle = item.groupTitle,
                    logoUrl = item.logoUrl,
                    streamUrl = item.streamUrl,
                    adult = isAdult(item.name, item.groupTitle)
                )
            }
            if (items.isNotEmpty()) {
                db.mediaDao().upsertAll(items)
                db.mediaDao().deleteMissing(source.id, items.map { it.id })
            }
            db.sourceDao().markSynced(source.id, System.currentTimeMillis())
            items.size
        }
    }

    private fun download(urlString: String): String {
        val conn = URL(urlString).openConnection() as HttpURLConnection
        conn.connectTimeout = 15000
        conn.readTimeout = 30000
        conn.requestMethod = "GET"
        conn.instanceFollowRedirects = true
        return conn.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }.also { conn.disconnect() }
    }
    private fun stableId(source: Long, key: String, url: String): String = sha256("$source|$key|$url")
    private fun sha256(s: String): String = MessageDigest.getInstance("SHA-256").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
    private fun classify(group: String?, name: String): String {
        val s = "${group.orEmpty()} $name".lowercase()
        return when {
            listOf("anime", "animes").any { it in s } -> "ANIME"
            listOf("filme", "filmes", "movie").any { it in s } -> "MOVIE"
            listOf("série", "series", "season", "temporada").any { it in s } -> "SERIES"
            else -> "CHANNEL"
        }
    }
    private fun isAdult(name: String, group: String?): Boolean {
        val s = "${group.orEmpty()} $name".lowercase()
        return listOf("adult", "adulto", "xxx", "porn", "erótico", "erotico").any { it in s }
    }
}
